import { useNavigate } from "react-router-dom";
import { useAuth } from "~/modules/auth/AuthContext.js";
import RegisterPage from "~/modules/auth/RegisterPage";

export default function Register() {
    const navigate = useNavigate();
    const { login } = useAuth();

    async function handleRegister(data: any) {
        console.log("Регистрация пользователя:", data);

        try {
            const res = await fetch("http://localhost:5252/api/Auth/register", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data),
            });

            if (!res.ok) {
                const errorText = await res.text();
                console.error("Ошибка регистрации:", errorText);
                alert("Ошибка регистрации");
                return;
            }

            // Ожидаем, что сервер вернёт объект с user и token
            const result = await res.json();

            const { user, token } = result;

            if (!user || !token) {
                alert("Некорректный ответ сервера при регистрации");
                return;
            }

            // Вызываем login из контекста с user и token
            login(user, token);

            // Переходим на главную страницу
            navigate("/");
        } catch (err) {
            console.error("Ошибка при регистрации:", err);
            alert("Ошибка регистрации");
        }
    }

    return (
        <div style={{ display: "flex" }}>
            <main className="flex items-center justify-center min-h-screen p-4 flex-1 w-full">
                <RegisterPage onRegister={handleRegister} />
            </main>
        </div>
    );
}
