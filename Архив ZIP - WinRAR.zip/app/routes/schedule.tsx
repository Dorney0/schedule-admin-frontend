import type { Route } from "./+types/home";
import Sidebar from '../components/sidebar/Sidebar';
import SchedulePage from '../modules/schedule/SchedulePage';
export function meta({}: Route.MetaArgs) {
    return [
        { title: "Schedule" },
        { name: "description", content: "Welcome to Schedule!" },
    ];
}

export default function Home() {
    return (
        <div style={{ display: 'flex' }}>
            <Sidebar />
            <main className="flex items-center justify-center min-h-screen p-4 flex-1">
                <SchedulePage />
            </main>
        </div>
    );
}
